package polimorfismoVehiculosEQUIPO;

public class test {
    public static void main(String[] args) {
        auto a = new auto();
        System.out.println(a);
    }

}
